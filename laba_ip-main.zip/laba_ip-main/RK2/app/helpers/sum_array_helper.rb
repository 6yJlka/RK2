module SumArrayHelper
end
