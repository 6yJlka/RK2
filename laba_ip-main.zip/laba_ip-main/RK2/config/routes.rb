Rails.application.routes.draw do
  root 'sum_array#index'
end
